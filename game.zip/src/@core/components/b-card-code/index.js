import BCardCode from './BCardCode.vue';

export default BCardCode;
