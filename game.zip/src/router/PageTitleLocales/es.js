// If value of title is null then DEFAULT_TITLE will be used instead

export default {};
