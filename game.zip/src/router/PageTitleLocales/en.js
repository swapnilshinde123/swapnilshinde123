// If value of title is null then DEFAULT_TITLE will be used instead

export default {
  DEFAULT_TITLE: 'khelogtto',
  home: null,
  'auth-login': 'Login - khelogtto',
  'auth-register': 'Register - khelogtto',
  'auth-forgot': 'Password Recovery - khelogtto',
  'auth-reset-password': 'Password Recovery - khelogtto',
  'change-password': 'Change Password - khelogtto',
  'verify-account': 'Verify your account - khelogtto',
  'error-404': '404 - khelogtto',
};
