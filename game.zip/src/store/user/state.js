export default function () {
  return {
    user: {},
    requestPointBalance: 0,
  };
}
