import state from './state';

export function getUserDetails() {
  return state.user;
}
export function getRequestPointBalance() {
  return state.requestPointBalance;
}
