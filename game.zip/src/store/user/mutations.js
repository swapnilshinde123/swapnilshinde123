export function setUser(state, payload) {
  state.user = payload;
}
export function setRequestPointBalance(state, payload) {
  state.requestPointBalance = payload;
}
