import APIService from '@/libs/api/api';

export async function getProfileDetails(ctx) {
  ctx.commit('setUser');
}
